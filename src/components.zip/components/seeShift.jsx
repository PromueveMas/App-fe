import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import { URL } from "../utils/constants";
import {
  Spinner,
  Center,
  Box,
  Heading,
  Text,
  Image,
  VStack,
} from "@chakra-ui/react";

const SeeShift = () => {
  const { shiftId } = useParams();
  const data = JSON.parse(localStorage.getItem("data"));
  const [shift, setShift] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  console.log("** SHIFT **", shiftId);

  useEffect(() => {
    const fetchShifts = async () => {
      try {
        const headers = {
          authorization: data.token,
        };
        const response = await axios.get(`${URL}/getShifts?id=${shiftId}`, {
          headers,
        });
        console.log("SHIFTS DETALLE: ", response);
        setShift(response.data[0]);
      } catch (error) {
        console.error("Error al obtener los turnos:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchShifts();
  }, []);

  if (isLoading) {
    return (
      <Center p="8">
        <Spinner size="xl" />
      </Center>
    );
  }

  return (
    <Box
      p="8"
      width="800px"
      borderWidth="1px"
      borderRadius="lg"
      boxShadow="lg"
      bg="white"
    >
      <VStack spacing={4} align="stretch">
        <Heading size="lg">Coordinador: {shift.coordinatorName}</Heading>
        <Text fontSize="md">Fecha: {shift.date}</Text>
        <Text fontSize="md">Hora: {shift.hour}</Text>
        <Text fontSize="md">Grupo: {shift.group}</Text>
        <Text fontSize="md">Zona: {shift.zone}</Text>
        <Text fontSize="md">Observaciones: {shift.observations}</Text>
        {shift.imageBase64 && (
          <Box boxSize="sm">
            <Image src={shift.imageBase64} alt="Shift" objectFit="cover" />
          </Box>
        )}
      </VStack>
    </Box>
  );
};
export default SeeShift;
